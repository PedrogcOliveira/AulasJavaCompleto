package classe;

public class PrimeiroTrauma {

	int a = 3;
	
	public static void main(String[] args) {
	
		coisa();
		
		//Variação da resolução
		//PrimeiroTrauma p1 = new PrimeiroTrauma();
		//   System.out.println(p1.a);
		
	}
	
	static void coisa() {
	   PrimeiroTrauma p1 = new PrimeiroTrauma();
	   System.out.println(p1.a);
	}
}
