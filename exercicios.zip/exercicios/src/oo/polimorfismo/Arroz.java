package oo.polimorfismo;

public class Arroz extends Comida{

	private double peso;
	
	public Arroz(double peso) {
		super(peso);
	}
}
