package oo.polimorfismo;

public class Sorvete extends Comida{

	private double peso;
	
	public Sorvete(double peso) {
		super(peso);
	}
}
