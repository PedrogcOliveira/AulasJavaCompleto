package oo.polimorfismo;

public class Feijao extends Comida{

	private double peso;
	
	public Feijao(double peso) {
		super(peso);
	}

}
