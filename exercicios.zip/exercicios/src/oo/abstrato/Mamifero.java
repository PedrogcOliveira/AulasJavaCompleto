package oo.abstrato;

public abstract class Mamifero extends Animal{

	
	public String mover() {
		return "Usando as patas";
	}
	
	public abstract String mamar();
}
