package oo.heranca.desafio;

public class Monza extends Carro{

	public Monza() {
		super(180);
	}
}
