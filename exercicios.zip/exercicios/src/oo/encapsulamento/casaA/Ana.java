package oo.encapsulamento.casaA;

public class Ana {

	@SuppressWarnings ("unused")
	private String segredo = "....";
	String facoDentroDeCasa = "...";
	protected String formaDeFalar = "..";
	public String todosSabem = ".";
	
	
}
