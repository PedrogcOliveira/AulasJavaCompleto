package fundamentos;

public class TipoStringEquals {
	
	public static void main(String[] args) {
		
		//Sempre comparar Strigns com .equals
		String s1 = new String("2");
		System.out.println("2".equals(s1.trim()));
		
		//Noitação .trim() serve para tirar os espaços do que o usuário digitar
	}
}
