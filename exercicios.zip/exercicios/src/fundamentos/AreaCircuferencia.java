package fundamentos;

public class AreaCircuferencia {
	public static void main(String[] args) {
		double raio = 3.4;
		//Definir a variável como uma constante
		final double pi = 3.14159;
		
		double area = pi * raio * raio;
		
		System.out.println(area);
	}
}
