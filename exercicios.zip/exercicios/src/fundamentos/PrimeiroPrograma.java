package fundamentos;

public class PrimeiroPrograma {
	
	// Comentário de linha
	
	/**
	 * JAVA DOC
	 * @param args
	 */
	public static void main(String [] args) {
		System.out.println("Hello World!");
		
		/*
		 * Comentário de bloco
		 */
	}
}
