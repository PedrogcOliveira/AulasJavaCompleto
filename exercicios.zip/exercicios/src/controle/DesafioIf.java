package controle;

public class DesafioIf {

	public static void main(String[] args) {
		
		double nota = 1.3;
		
		
		//Não usar ; em uma estrutura de controle(fora exceções)
		if (nota >= 9.0) {
			System.out.println("Quadro de Honra!");
			System.out.println("Você é fera!!");
		}
	}
}
