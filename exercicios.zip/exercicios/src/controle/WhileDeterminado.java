package controle;

public class WhileDeterminado {

	
	public static void main(String[] args) {
		
		int contador = 1;
		
		while (contador <=10) {
			System.out.println("Bom dia!");
			System.out.printf("i = %d\n", contador);
			contador++;
		}
		
	}
}
