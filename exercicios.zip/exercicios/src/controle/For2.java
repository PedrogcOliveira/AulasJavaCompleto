package controle;


public class For2 {

	public static void main(String[] args) {
		
		

		
		for (int i = 10; i >= 0 ; i-=2) {	
			System.out.println("O número atual é: " + i);	
			//System.out.println("O número atual é: + i--") Para subtrair novamente o número
		}
		
		
		

	}
}
