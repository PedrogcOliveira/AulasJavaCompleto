package controle;

public class DesafioFor {

	public static void main(String[] args) {
		
		String valor = "#";
//		for (int i = 1; i <= 5; i++) {
//			System.out.println(valor);
//			valor += "#";
//		}
		
		
		//Desafio FOR
		for (String j = "#"; !j.equals("######") ; j += "#") {
			System.out.println(valor);
		}
	}
}
