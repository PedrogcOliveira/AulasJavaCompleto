package controle;


public class For1 {

	public static void main(String[] args) {
		

//		Usando a Estrutura do For em um While determinado
//		int contador = 1;		
//		while (contador <=10) {
//			System.out.println("Bom dia!");
//			System.out.printf("i = %d\n", contador);
//			contador++;
//		}
//		
		for (int i = 0; i <= 10 ; i++) {
			System.out.printf("i = %d\n", i);
			
		}
		
		//Laço infinito
//		for (;true;) {
//			System.out.println("Fim");
//			
//		}
	}
}
