/**
 * 
 */
/**
 * 
 */
module exercicios {
	requires java.desktop;
}